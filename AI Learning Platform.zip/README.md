
  # AI Learning Platform

  This is a code bundle for AI Learning Platform. The original project is available at https://www.figma.com/design/wLWvMXnlhkAVlTAeC6hNj4/AI-Learning-Platform.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  